레디보드 받은편지함 시연 HTML

readyboard-review.html을 Chrome 또는 Edge에서 여세요.
새 메일 확인 → 5통 수집 → 규칙 기반 분석 → 초안 2건 → 검토·승인을 시연할 수 있습니다.
HTML의 모든 데이터는 합성 시연 자료이며 현재 탭의 메모리에서만 바뀝니다. 새로고침하면 초기화됩니다.
외부 메일·실제 AI·실제 DB 저장은 서버 실행이 필요합니다.
파일 열기가 제한되면 Node.js 설치 후 open-preview.cmd 또는 node serve-review.cjs를 실행하세요.
