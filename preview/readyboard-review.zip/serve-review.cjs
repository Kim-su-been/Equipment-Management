const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const filename = path.join(__dirname, 'readyboard-review.html');
if (!fs.existsSync(filename)) { console.error('Keep this script and readyboard-review.html in the same folder.'); process.exit(1); }
const server = http.createServer((req, res) => {
  if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405); return res.end(); }
  const pathname = new URL(req.url, 'http://localhost').pathname;
  if (pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
  if (!['/', '/readyboard-review.html'].includes(pathname)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(filename).pipe(res);
});
server.listen(0, '127.0.0.1', () => {
  const url = `http://127.0.0.1:${server.address().port}`;
  console.log(`Readyboard review: ${url}\nKeep this window open. Ctrl+C to stop. No files are saved by the preview.`);
  if (process.platform === 'win32') { const child = spawn('cmd.exe', ['/c', 'start', '', url], { stdio: 'ignore', windowsHide: true }); child.on('error', () => {}); }
});
