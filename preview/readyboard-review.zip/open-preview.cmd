@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Please open readyboard-review.html in your browser.
  pause
  exit /b 1
)
node serve-review.cjs
pause
